import csv
import os
import re
import nltk
import scipy
import sklearn.metrics
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn import svm
from sklearn.externals import joblib
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB

def getTrainingAndTestData():
        X = []
        y = []

        #Training data 1: Sentiment 140
       # f=open(r'F:\\ANEELA\\Data\\Altmetrics_Dataset_cleaned.csv','r', encoding='ISO-8859-1')
        f=open(r'DataICDM_ALL.csv','r', encoding='ISO-8859-1')
        reader = csv.reader(f)
        for row in reader:
            X.append(row[0])
#            if row[13]=='positive':
#                y.append(1)
#            elif row[13]=='negative':
#                y.append(-1)
#            else:
#                y.append(0)
            y.append(row[1])
        X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.50, random_state=42)
        return X_train, X_test, y_train, y_test

# SVM classifier
def svmClassifier(X_train,y_train):
        vec = TfidfVectorizer(min_df=3, max_df=0.95, sublinear_tf = True,use_idf = True,ngram_range=(1, 2))
        svm_clf =svm.LinearSVC(C=0.04,max_iter=1000)
        vec_clf = Pipeline([('vectorizer', vec), ('pac', svm_clf)])
        vec_clf.fit(X_train,y_train)
        return vec_clf
        
# NB classifier
def NBClassifier(X_train,y_train):
        vec = TfidfVectorizer(min_df=3, max_df=0.95, sublinear_tf = True,use_idf = True,ngram_range=(1, 2))
        nb_clf = MultinomialNB()
        vec_clf = Pipeline([('vectorizer', vec), ('pac', nb_clf)])
        vec_clf.fit(X_train,y_train)
        return vec_clf

# Main function
def main(arg):
        X_train, X_test, y_train, y_test = getTrainingAndTestData()
        if arg=='nb':
            vec_clf = NBClassifier(X_train,y_train)
        elif arg=='svm':
            vec_clf = svmClassifier(X_train,y_train)
        y_pred = vec_clf.predict(X_test)
        print(y_pred)
        print(sklearn.metrics.classification_report(y_test,y_pred))  
        print(sklearn.metrics.accuracy_score(y_test, y_pred, normalize=True, sample_weight=None))
        
if __name__ == "__main__":
    model="svm"
    main(arg=model)

    